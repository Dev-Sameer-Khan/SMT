
import { TranslationSet, Product } from './types';

export const TRANSLATIONS: Record<'en' | 'ar', TranslationSet> = {
  en: {
    navHome: 'Home',
    navAbout: 'About',
    navProducts: 'Products',
    navContact: 'Contact',
    ctaInquiry: 'Direct Inquiry',
    heroTitle: 'INDUSTRIAL PRECISION',
    heroTagline: 'Engineering Excellence at Scale',
    heroDesc: 'Elite global supplier of high-performance engine components, filtration systems, and industrial compressors.',
    heroBtnProducts: 'View Capabilities',
    heroBtnInquiry: 'Technical Inquiry',
    statsProducts: 'Inventory Units',
    statsExperience: 'Years Expertise',
    statsProjects: 'Global Deliveries',
    statsClients: 'Key Partners',
    launchTitle: 'Pioneering Air Power: The Compressor Division',
    launchBadge: 'NEW DIVISION',
    aboutTitle: 'RELIABILITY ENGINEERED',
    aboutSubtitle: 'A Legacy of Industrial Trust',
    aboutText: 'Focused on high-performance engine components and heavy-duty filtration. Our supply chain ensures zero downtime for global fleet owners and industrial projects.',
    productCategories: 'CORE CAPABILITIES',
    faqTitle: 'TECHNICAL SPECIFICATIONS & FAQ',
    contactTitle: 'ESTABLISH PARTNERSHIP',
    footerTagline: 'Defining the standards of industrial part supply since 1998.'
  },
  ar: {
    navHome: 'الرئيسية',
    navAbout: 'من نحن',
    navProducts: 'المنتجات',
    navContact: 'اتصل بنا',
    ctaInquiry: 'استفسار مباشر',
    heroTitle: 'دقة صناعية',
    heroTagline: 'التميز الهندسي على نطاق واسع',
    heroDesc: 'مورد عالمي لنخبة مكونات المحركات، وأنظمة الترشيح، والضواغط الصناعية.',
    heroBtnProducts: 'عرض الإمكانيات',
    heroBtnInquiry: 'استفسار فني',
    statsProducts: 'وحدات المخزون',
    statsExperience: 'سنوات الخبرة',
    statsProjects: 'تسليمات عالمية',
    statsClients: 'شركاء رئيسيون',
    launchTitle: 'ريادة طاقة الهواء: قسم الضواغط',
    launchBadge: 'قسم جديد',
    aboutTitle: 'موثوقية هندسية',
    aboutSubtitle: 'إرث من الثقة الصناعية',
    aboutText: 'نركز على مكونات المحركات عالية الأداء والترشيح الشاق. تضمن سلسلة التوريد الخاصة بنا عدم وجود فترات توقف لأصحاب الأساطيل العالمية.',
    productCategories: 'القدرات الأساسية',
    faqTitle: 'المواصفات الفنية والأسئلة الشائعة',
    contactTitle: 'تأسيس شراكة',
    footerTagline: 'تحديد معايير توريد قطع الغيار الصناعية منذ عام 1998.'
  }
};

export const PRODUCTS: Product[] = [
  {
    id: '1',
    title: 'V12 Piston Assembly',
    category: 'engine',
    desc: 'High-thermal tolerance alloy with precision coating.',
    specs: 'Heavy Duty Marine & Industrial',
    image: 'https://picsum.photos/seed/engine1/800/600'
  },
  {
    id: '2',
    title: 'Multi-Stage Screw Compressor',
    category: 'compressor',
    desc: 'Oil-free compression for pharmaceutical applications.',
    specs: '350 CFM | Variable Speed',
    image: 'https://picsum.photos/seed/comp1/800/600'
  },
  {
    id: '3',
    title: 'Nanofiber Fuel Filter',
    category: 'filter',
    desc: 'Advanced particulate capture for high-pressure common rail systems.',
    specs: 'Efficiency 99.9%',
    image: 'https://picsum.photos/seed/filter1/800/600'
  },
  {
    id: '4',
    title: 'Gasket Performance Kit',
    category: 'spare',
    desc: 'Full sealing solution for heavy earthmovers.',
    specs: 'Heat Resilient Fluoroelastomer',
    image: 'https://picsum.photos/seed/parts1/800/600'
  }
];
