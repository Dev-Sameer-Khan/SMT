
import React from 'react';
import { useLanguage } from '../App';
import { Mail, Phone, MapPin, Linkedin, Twitter, Youtube } from 'lucide-react';
import { Link } from 'react-router-dom';

const Footer: React.FC = () => {
  const { t } = useLanguage();

  return (
    <footer className="bg-[#0A0A0A] text-white pt-24 pb-12 border-t border-white/5">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-20">
          {/* Brand */}
          <div className="space-y-6">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-red-600 flex items-center justify-center rounded-sm">
                <span className="text-white font-bold text-lg">I</span>
              </div>
              <span className="text-xl font-bold tracking-tighter">PRECISION</span>
            </div>
            <p className="text-white/50 text-sm leading-relaxed max-w-xs">
              {t.footerTagline}
            </p>
            <div className="flex gap-4 pt-4">
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-red-600 transition-colors">
                <Linkedin className="w-4 h-4" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-red-600 transition-colors">
                <Twitter className="w-4 h-4" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-red-600 transition-colors">
                <Youtube className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Links */}
          <div className="space-y-6">
            <h4 className="text-sm font-bold uppercase tracking-widest text-red-500">Navigation</h4>
            <ul className="space-y-4">
              <li><Link to="/" className="text-white/60 hover:text-white transition-colors">{t.navHome}</Link></li>
              <li><Link to="/about" className="text-white/60 hover:text-white transition-colors">{t.navAbout}</Link></li>
              <li><Link to="/products" className="text-white/60 hover:text-white transition-colors">{t.navProducts}</Link></li>
              <li><Link to="/contact" className="text-white/60 hover:text-white transition-colors">{t.navContact}</Link></li>
            </ul>
          </div>

          {/* Industrial Divisions */}
          <div className="space-y-6">
            <h4 className="text-sm font-bold uppercase tracking-widest text-red-500">Divisions</h4>
            <ul className="space-y-4 text-white/60">
              <li>Engine Components</li>
              <li>Industrial Filtration</li>
              <li>Screw Compressors</li>
              <li>Heavy Spares</li>
            </ul>
          </div>

          {/* Contact */}
          <div className="space-y-6">
            <h4 className="text-sm font-bold uppercase tracking-widest text-red-500">Global Hub</h4>
            <ul className="space-y-4">
              <li className="flex gap-3 text-white/60">
                <MapPin className="w-5 h-5 text-red-600 flex-shrink-0" />
                <span className="text-sm">Industrial Area 4, Hub 12, Dubai, UAE</span>
              </li>
              <li className="flex gap-3 text-white/60">
                <Phone className="w-5 h-5 text-red-600 flex-shrink-0" />
                <span className="text-sm">+971 4 000 0000</span>
              </li>
              <li className="flex gap-3 text-white/60">
                <Mail className="w-5 h-5 text-red-600 flex-shrink-0" />
                <span className="text-sm">logistics@iprecision.com</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-12 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6 text-white/30 text-xs font-mono tracking-widest uppercase">
          <p>© 2024 Industrial Precision Ltd. All Rights Reserved.</p>
          <div className="flex gap-8">
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
