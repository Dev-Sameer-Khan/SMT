
import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useLanguage } from '../App';
import { Globe } from 'lucide-react';

const Header: React.FC = () => {
  const { lang, setLang, t } = useLanguage();
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { name: t.navHome, path: '/' },
    { name: t.navAbout, path: '/about' },
    { name: t.navProducts, path: '/products' },
    { name: t.navContact, path: '/contact' },
  ];

  return (
    <header
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-500 ${
        scrolled ? 'py-4 glass-dark' : 'py-8 bg-transparent'
      }`}
    >
      <div className="container mx-auto px-6 flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2">
          <div className="w-10 h-10 bg-red-600 flex items-center justify-center rounded-sm">
            <span className="text-white font-bold text-xl">I</span>
          </div>
          <span className={`text-2xl font-bold tracking-tighter ${scrolled || location.pathname !== '/' ? 'text-white' : 'text-white'}`}>
            PRECISION
          </span>
        </Link>

        {/* Navigation */}
        <nav className="hidden md:flex items-center gap-8">
          {navItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={`text-sm font-medium uppercase tracking-widest transition-colors ${
                location.pathname === item.path
                  ? 'text-red-500'
                  : 'text-white/80 hover:text-white'
              }`}
            >
              {item.name}
            </Link>
          ))}
        </nav>

        {/* Actions */}
        <div className="flex items-center gap-6">
          <button
            onClick={() => setLang(lang === 'en' ? 'ar' : 'en')}
            className="flex items-center gap-2 text-white/80 hover:text-white text-xs font-mono uppercase tracking-widest"
          >
            <Globe className="w-4 h-4" />
            {lang === 'en' ? 'AR' : 'EN'}
          </button>
          
          <Link
            to="/contact"
            className="hidden sm:block px-6 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-bold uppercase tracking-widest rounded-sm transition-all shadow-xl hover:shadow-red-900/40"
          >
            {t.ctaInquiry}
          </Link>
        </div>
      </div>
    </header>
  );
};

export default Header;
